# Food Quality Detector

A modern, AI-powered web application for detecting food quality using machine learning. Built with Spring Boot, Java, and MySQL, this application analyzes uploaded food images to classify them as "Fresh" or "Spoiled" with confidence scores.

## 🚀 Features

- **AI-Powered Detection**: Uses Deep Java Library (DJL) for image classification
- **Image Upload**: Drag-and-drop interface for easy image uploads
- **Real-time Analysis**: Instant classification results with confidence percentages
- **History Tracking**: Complete record of all detections with filtering options
- **Modern UI**: Clean, responsive design with beautiful animations
- **Database Storage**: MySQL backend for persistent data storage
- **RESTful API**: Well-structured Spring Boot architecture

## 🏗️ Architecture

The application follows a clean, layered architecture:

```
Controller Layer (REST endpoints)
    ↓
Service Layer (Business logic)
    ↓
Repository Layer (Data access)
    ↓
Entity Layer (Data models)
```

### Key Components

- **Controller**: Handles HTTP requests and responses
- **Service**: Contains business logic and AI processing
- **Repository**: Manages database operations
- **Entity**: JPA entities for data persistence
- **DTO**: Data Transfer Objects for API communication

## 🛠️ Technology Stack

- **Backend**: Java 17, Spring Boot 3.2.0
- **AI/ML**: Deep Java Library (DJL) 0.22.1
- **Database**: MySQL 8.0
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Template Engine**: Thymeleaf
- **Build Tool**: Maven

## 📋 Prerequisites

Before running this application, ensure you have:

- **Java 17** or higher
- **Maven 3.6** or higher
- **MySQL 8.0** or higher
- **Git** (for cloning the repository)

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone <repository-url>
cd food-quality-detector
```

### 2. Database Setup

1. **Start MySQL Server**
   ```bash
   # On Windows
   net start mysql
   
   # On macOS/Linux
   sudo systemctl start mysql
   ```

2. **Create Database** (optional - will be auto-created)
   ```sql
   CREATE DATABASE food_quality_db;
   ```

3. **Update Configuration**
   Edit `src/main/resources/application.properties`:
   ```properties
   spring.datasource.username=your_username
   spring.datasource.password=your_password
   ```

### 3. Build and Run

```bash
# Clean and compile
mvn clean compile

# Run the application
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

### 4. Access the Application

- **Home Page**: `http://localhost:8080/food-detection/`
- **Upload Page**: `http://localhost:8080/food-detection/upload`
- **History Page**: `http://localhost:8080/food-detection/history`

## 📁 Project Structure

```
src/
├── main/
│   ├── java/
│   │   └── com/foodquality/
│   │       ├── controller/
│   │       │   └── FoodDetectionController.java
│   │       ├── service/
│   │       │   ├── FoodDetectionService.java
│   │       │   └── FoodQualityDetectionService.java
│   │       ├── repository/
│   │       │   └── FoodDetectionRepository.java
│   │       ├── entity/
│   │       │   └── FoodDetectionResult.java
│   │       ├── dto/
│   │       │   ├── FoodDetectionRequest.java
│   │       │   └── FoodDetectionResponse.java
│   │       └── FoodQualityDetectorApplication.java
│   └── resources/
│       ├── static/
│       │   └── css/
│       │       └── styles.css
│       ├── templates/
│       │   ├── home.html
│       │   ├── upload.html
│       │   ├── result.html
│       │   └── history.html
│       └── application.properties
└── test/
    └── java/
        └── com/foodquality/
```

## 🔧 Configuration

### Application Properties

Key configuration options in `application.properties`:

```properties
# Database
spring.datasource.url=jdbc:mysql://localhost:3306/food_quality_db
spring.datasource.username=root
spring.datasource.password=password

# File Upload
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB

# Server
server.port=8080
```

### Environment Variables

You can override database settings using environment variables:

```bash
export SPRING_DATASOURCE_USERNAME=your_username
export SPRING_DATASOURCE_PASSWORD=your_password
```

## 🎯 Usage

### 1. Upload an Image

1. Navigate to the Upload page
2. Drag and drop an image or click to browse
3. Supported formats: JPG, PNG, GIF, BMP
4. Maximum file size: 10MB
5. Click "Analyze Food Quality"

### 2. View Results

After analysis, you'll see:
- **Classification**: Fresh or Spoiled
- **Confidence Score**: Percentage of certainty
- **File Details**: Name, size, type, timestamp
- **Visual Indicators**: Color-coded results

### 3. Access History

- View all previous detections
- Filter by classification (Fresh/Spoiled)
- Delete individual results
- View detailed statistics

## 🤖 AI/ML Implementation

### Current Implementation

The application currently uses a **rule-based approach** for demonstration purposes:

- **File Size Heuristic**: Larger files (>1MB) classified as "Fresh"
- **Confidence Calculation**: Simulated confidence scores
- **Processing Time**: Simulated 1-second delay

### Production-Ready Implementation

To implement a real AI model:

1. **Train a Model**: Use food quality datasets
2. **Export Model**: Save in PyTorch/ONNX format
3. **Update Service**: Replace rule-based logic with model inference
4. **Model Loading**: Use DJL to load and serve the model

Example model integration:

```java
// Load pre-trained model
Criteria<Image, Classifications> criteria = Criteria.builder()
    .setTypes(Image.class, Classifications.class)
    .optModelPath(Paths.get("models/food-quality-classifier.pt"))
    .optTranslator(translator)
    .build();

ZooModel<Image, Classifications> model = ModelZoo.loadModel(criteria);
Predictor<Image, Classifications> predictor = model.newPredictor();
```

## 🧪 Testing

### Run Tests

```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=FoodDetectionServiceTest

# Run with coverage
mvn test jacoco:report
```

### Test Coverage

The application includes comprehensive tests for:
- Service layer business logic
- Repository data access
- Controller request handling
- Entity validation

## 📊 Database Schema

### Food Detection Results Table

```sql
CREATE TABLE food_detection_results (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    original_file_name VARCHAR(255) NOT NULL,
    classification VARCHAR(50) NOT NULL,
    confidence_score DOUBLE NOT NULL,
    upload_timestamp DATETIME NOT NULL,
    file_size BIGINT,
    content_type VARCHAR(100)
);
```

## 🚀 Deployment

### Production Deployment

1. **Build JAR**
   ```bash
   mvn clean package -DskipTests
   ```

2. **Run JAR**
   ```bash
   java -jar target/food-quality-detector-1.0.0.jar
   ```

3. **Docker Deployment**
   ```dockerfile
   FROM openjdk:17-jre-slim
   COPY target/food-quality-detector-1.0.0.jar app.jar
   EXPOSE 8080
   ENTRYPOINT ["java", "-jar", "/app.jar"]
   ```

### Environment Considerations

- **Database**: Use production MySQL with proper security
- **File Storage**: Consider cloud storage for uploaded images
- **AI Model**: Deploy model files separately or use model serving
- **Monitoring**: Add logging and health checks

## 🔒 Security Considerations

- **File Upload**: Validate file types and sizes
- **Database**: Use connection pooling and prepared statements
- **Input Validation**: Sanitize all user inputs
- **Error Handling**: Don't expose sensitive information in errors

## 📈 Performance Optimization

- **Database Indexing**: Add indexes on frequently queried columns
- **Caching**: Implement Redis for session and result caching
- **Async Processing**: Use @Async for image processing
- **Connection Pooling**: Configure HikariCP for database connections

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check MySQL service status
   - Verify credentials in application.properties
   - Ensure database exists

2. **File Upload Errors**
   - Check file size limits
   - Verify supported formats
   - Check uploads directory permissions

3. **AI Model Issues**
   - Verify DJL dependencies
   - Check model file paths
   - Review error logs

### Logs

Enable debug logging in `application.properties`:

```properties
logging.level.com.foodquality=DEBUG
logging.level.org.springframework.web=DEBUG
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Spring Boot Team** for the excellent framework
- **DJL Community** for Java ML capabilities
- **MySQL Team** for the robust database
- **Open Source Contributors** for inspiration and tools

## 📞 Support

For questions or issues:

1. Check the troubleshooting section
2. Review application logs
3. Create an issue in the repository
4. Contact the development team

---

**Built with ❤️ using Spring Boot and AI/ML technologies** 