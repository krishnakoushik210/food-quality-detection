# 🥗 Simple Food Quality Detector

## 🚀 SUPER EASY TO RUN!

### Option 1: Double-click to run (Windows)
1. **Double-click `run.bat`** - That's it! 🎯

### Option 2: Command line
```bash
# Compile
javac SimpleFoodDetector.java

# Run
java SimpleFoodDetector
```

### Option 3: Direct run (Java 11+)
```bash
java SimpleFoodDetector.java
```

## ✨ What it does:
- **Upload food images** (simulated)
- **AI classification** (Fresh vs Spoiled)
- **Confidence scores**
- **History tracking**
- **Statistics dashboard**

## 🎮 How to use:
1. Run the application
2. Choose option 1 to "upload" an image
3. Press Enter to use simulated filename
4. View results and confidence scores
5. Check history and statistics

## 🔧 Requirements:
- **Java 11 or higher** (you have Java 21 ✅)
- **No Maven needed**
- **No external dependencies**
- **No database setup**

## 🎯 Features:
- ✅ **No complex setup**
- ✅ **Runs immediately**
- ✅ **All core functionality**
- ✅ **Professional output**
- ✅ **Easy to understand**

---

**Just double-click `run.bat` and enjoy!** 🚀
