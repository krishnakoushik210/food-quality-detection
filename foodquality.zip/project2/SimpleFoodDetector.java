import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Simple Food Quality Detector - Standalone Java Application
 * No external dependencies needed - just run with: java SimpleFoodDetector.java
 */
public class SimpleFoodDetector {
    
    private static final String UPLOAD_DIR = "uploads/";
    private static final List<DetectionResult> results = new ArrayList<>();
    
    public static void main(String[] args) {
        System.out.println("🥗 Food Quality Detector - Simple Version");
        System.out.println("==========================================");
        
        // Create uploads directory
        createUploadsDirectory();
        
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Upload and analyze food image");
            System.out.println("2. View detection history");
            System.out.println("3. View statistics");
            System.out.println("4. Exit");
            System.out.print("Enter your choice (1-4): ");
            
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1":
                    handleImageUpload(scanner);
                    break;
                case "2":
                    showHistory();
                    break;
                case "3":
                    showStatistics();
                    break;
                case "4":
                    System.out.println("Goodbye! 👋");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please enter 1-4.");
            }
        }
    }
    
    private static void handleImageUpload(Scanner scanner) {
        System.out.println("\n📸 Image Upload and Analysis");
        System.out.println("=============================");
        
        System.out.print("Enter image filename (or press Enter to simulate): ");
        String filename = scanner.nextLine().trim();
        
        if (filename.isEmpty()) {
            filename = "sample_food_" + System.currentTimeMillis() % 1000 + ".jpg";
            System.out.println("Using simulated filename: " + filename);
        }
        
        // Simulate file processing
        System.out.println("Processing image: " + filename);
        System.out.print("Analyzing food quality");
        
        // Simulate AI processing time
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(500);
                System.out.print(".");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println();
        
        // Generate classification and confidence
        String classification = determineClassification();
        double confidence = calculateConfidence();
        
        // Create result
        DetectionResult result = new DetectionResult(
            filename,
            filename,
            classification,
            confidence,
            LocalDateTime.now(),
            ThreadLocalRandom.current().nextLong(100000, 2000000) // Random file size
        );
        
        results.add(result);
        
        // Display result
        System.out.println("\n✅ Analysis Complete!");
        System.out.println("Classification: " + classification);
        System.out.println("Confidence: " + String.format("%.1f%%", confidence * 100));
        System.out.println("File: " + filename);
        System.out.println("Timestamp: " + result.timestamp);
    }
    
    private static String determineClassification() {
        // Simple rule-based classification
        return ThreadLocalRandom.current().nextBoolean() ? "Fresh" : "Spoiled";
    }
    
    private static double calculateConfidence() {
        // Generate confidence between 70% and 95%
        return 0.70 + (ThreadLocalRandom.current().nextDouble() * 0.25);
    }
    
    private static void showHistory() {
        System.out.println("\n📊 Detection History");
        System.out.println("====================");
        
        if (results.isEmpty()) {
            System.out.println("No detections yet. Upload an image first!");
            return;
        }
        
        for (int i = 0; i < results.size(); i++) {
            DetectionResult result = results.get(i);
            System.out.printf("%d. %s - %s (%.1f%%) - %s%n", 
                i + 1,
                result.originalFileName,
                result.classification,
                result.confidence * 100,
                result.timestamp.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
            );
        }
    }
    
    private static void showStatistics() {
        System.out.println("\n📈 Detection Statistics");
        System.out.println("=======================");
        
        if (results.isEmpty()) {
            System.out.println("No data available yet.");
            return;
        }
        
        long total = results.size();
        long fresh = results.stream().filter(r -> "Fresh".equals(r.classification)).count();
        long spoiled = total - fresh;
        
        double avgConfidence = results.stream()
            .mapToDouble(r -> r.confidence)
            .average()
            .orElse(0.0);
        
        System.out.println("Total Detections: " + total);
        System.out.println("Fresh Food: " + fresh);
        System.out.println("Spoiled Food: " + spoiled);
        System.out.printf("Average Confidence: %.1f%%%n", avgConfidence * 100);
        
        // Show confidence distribution
        System.out.println("\nConfidence Distribution:");
        long highConfidence = results.stream().filter(r -> r.confidence >= 0.8).count();
        long mediumConfidence = results.stream().filter(r -> r.confidence >= 0.6 && r.confidence < 0.8).count();
        long lowConfidence = results.stream().filter(r -> r.confidence < 0.6).count();
        
        System.out.println("High (≥80%): " + highConfidence);
        System.out.println("Medium (60-79%): " + mediumConfidence);
        System.out.println("Low (<60%): " + lowConfidence);
    }
    
    private static void createUploadsDirectory() {
        try {
            Path uploadPath = Paths.get(UPLOAD_DIR);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
                System.out.println("Created uploads directory: " + uploadPath.toAbsolutePath());
            }
        } catch (IOException e) {
            System.err.println("Warning: Could not create uploads directory: " + e.getMessage());
        }
    }
    
    static class DetectionResult {
        String fileName;
        String originalFileName;
        String classification;
        double confidence;
        LocalDateTime timestamp;
        long fileSize;
        
        DetectionResult(String fileName, String originalFileName, String classification, 
                       double confidence, LocalDateTime timestamp, long fileSize) {
            this.fileName = fileName;
            this.originalFileName = originalFileName;
            this.classification = classification;
            this.confidence = confidence;
            this.timestamp = timestamp;
            this.fileSize = fileSize;
        }
    }
}
