package com.foodquality;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot application class for Food Quality Detector
 * 
 * This application provides AI-powered food quality detection using
 * Deep Java Library (DJL) for image classification.
 */
@SpringBootApplication
public class FoodQualityDetectorApplication {

    public static void main(String[] args) {
        SpringApplication.run(FoodQualityDetectorApplication.class, args);
    }
} 