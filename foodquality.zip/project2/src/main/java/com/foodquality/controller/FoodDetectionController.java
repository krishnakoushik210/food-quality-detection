package com.foodquality.controller;

import com.foodquality.dto.FoodDetectionResponse;
import com.foodquality.entity.FoodDetectionResult;
import com.foodquality.service.FoodDetectionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

/**
 * Controller for handling food detection web requests
 * 
 * This controller provides endpoints for uploading food images,
 * viewing detection results, and accessing detection history.
 */
@Controller
@RequestMapping("/food-detection")
public class FoodDetectionController {

    private static final Logger logger = LoggerFactory.getLogger(FoodDetectionController.class);

    private final FoodDetectionService detectionService;

    @Autowired
    public FoodDetectionController(FoodDetectionService detectionService) {
        this.detectionService = detectionService;
    }

    /**
     * Display the main food detection upload form
     * 
     * @param model the Spring model
     * @return the upload form view name
     */
    @GetMapping("/upload")
    public String showUploadForm(Model model) {
        logger.debug("Displaying food detection upload form");
        
        // Add any necessary model attributes
        model.addAttribute("pageTitle", "Food Quality Detection");
        model.addAttribute("maxFileSize", "10MB");
        model.addAttribute("supportedFormats", "JPG, PNG, GIF, BMP");
        
        return "upload";
    }

    /**
     * Handle food image upload and detection
     * 
     * @param imageFile the uploaded image file
     * @param redirectAttributes for flash messages
     * @param model the Spring model
     * @return the result view or redirect
     */
    @PostMapping("/upload")
    public String handleImageUpload(@RequestParam("imageFile") MultipartFile imageFile,
                                  RedirectAttributes redirectAttributes,
                                  Model model) {
        logger.info("Processing image upload: {}", imageFile.getOriginalFilename());
        
        try {
            // Process the image through the detection service
            FoodDetectionResponse response = detectionService.processFoodImage(imageFile);
            
            if (response.isSuccess()) {
                // Add the result to the model for display
                model.addAttribute("detectionResult", response);
                model.addAttribute("pageTitle", "Detection Result");
                model.addAttribute("success", true);
                
                logger.info("Image processing completed successfully");
                return "result";
                
            } else {
                // Add error message to redirect attributes
                redirectAttributes.addFlashAttribute("error", response.getMessage());
                logger.warn("Image processing failed: {}", response.getMessage());
                return "redirect:/food-detection/upload";
            }
            
        } catch (Exception e) {
            logger.error("Error during image upload processing", e);
            redirectAttributes.addFlashAttribute("error", 
                "An unexpected error occurred: " + e.getMessage());
            return "redirect:/food-detection/upload";
        }
    }

    /**
     * Display the detection history page
     * 
     * @param model the Spring model
     * @return the history view name
     */
    @GetMapping("/history")
    public String showHistory(Model model) {
        logger.debug("Displaying food detection history");
        
        try {
            // Get all detection results
            List<FoodDetectionResult> results = detectionService.getAllDetectionResults();
            
            // Get statistics
            FoodDetectionService.DetectionStatistics stats = 
                detectionService.getDetectionStatistics();
            
            // Add data to model
            model.addAttribute("detectionResults", results);
            model.addAttribute("statistics", stats);
            model.addAttribute("pageTitle", "Detection History");
            model.addAttribute("totalResults", results.size());
            
            logger.debug("Retrieved {} detection results for history display", results.size());
            
        } catch (Exception e) {
            logger.error("Error retrieving detection history", e);
            model.addAttribute("error", "Failed to load detection history: " + e.getMessage());
        }
        
        return "history";
    }

    /**
     * Display results filtered by classification
     * 
     * @param classification the food quality classification
     * @param model the Spring model
     * @return the filtered history view
     */
    @GetMapping("/history/{classification}")
    public String showHistoryByClassification(@PathVariable String classification, Model model) {
        logger.debug("Displaying detection history for classification: {}", classification);
        
        try {
            // Get results for specific classification
            List<FoodDetectionResult> results = 
                detectionService.getResultsByClassification(classification);
            
            // Get statistics
            FoodDetectionService.DetectionStatistics stats = 
                detectionService.getDetectionStatistics();
            
            // Add data to model
            model.addAttribute("detectionResults", results);
            model.addAttribute("statistics", stats);
            model.addAttribute("pageTitle", classification + " Food Detection History");
            model.addAttribute("filteredClassification", classification);
            model.addAttribute("totalResults", results.size());
            
            logger.debug("Retrieved {} results for classification: {}", 
                       results.size(), classification);
            
        } catch (Exception e) {
            logger.error("Error retrieving filtered detection history", e);
            model.addAttribute("error", "Failed to load filtered history: " + e.getMessage());
        }
        
        return "history";
    }

    /**
     * Display a specific detection result
     * 
     * @param id the detection result ID
     * @param model the Spring model
     * @return the result detail view or redirect
     */
    @GetMapping("/result/{id}")
    public String showDetectionResult(@PathVariable Long id, Model model) {
        logger.debug("Displaying detection result with ID: {}", id);
        
        try {
            var resultOpt = detectionService.getDetectionResultById(id);
            
            if (resultOpt.isPresent()) {
                FoodDetectionResult result = resultOpt.get();
                
                // Convert to response DTO for consistency
                FoodDetectionResponse response = new FoodDetectionResponse(
                    result.getFileName(),
                    result.getOriginalFileName(),
                    result.getClassification(),
                    result.getConfidenceScore()
                );
                response.setId(result.getId());
                response.setFileSize(result.getFileSize());
                response.setContentType(result.getContentType());
                response.setUploadTimestamp(result.getUploadTimestamp());
                
                model.addAttribute("detectionResult", response);
                model.addAttribute("pageTitle", "Detection Result Details");
                model.addAttribute("success", true);
                
                return "result";
                
            } else {
                logger.warn("Detection result not found with ID: {}", id);
                model.addAttribute("error", "Detection result not found");
                return "error";
            }
            
        } catch (Exception e) {
            logger.error("Error retrieving detection result", e);
            model.addAttribute("error", "Failed to load detection result: " + e.getMessage());
            return "error";
        }
    }

    /**
     * Delete a detection result
     * 
     * @param id the detection result ID to delete
     * @param redirectAttributes for flash messages
     * @return redirect to history page
     */
    @PostMapping("/delete/{id}")
    public String deleteDetectionResult(@PathVariable Long id, 
                                     RedirectAttributes redirectAttributes) {
        logger.info("Attempting to delete detection result with ID: {}", id);
        
        try {
            boolean deleted = detectionService.deleteDetectionResult(id);
            
            if (deleted) {
                redirectAttributes.addFlashAttribute("success", 
                    "Detection result deleted successfully");
                logger.info("Successfully deleted detection result with ID: {}", id);
            } else {
                redirectAttributes.addFlashAttribute("error", 
                    "Detection result not found or could not be deleted");
                logger.warn("Failed to delete detection result with ID: {}", id);
            }
            
        } catch (Exception e) {
            logger.error("Error deleting detection result with ID: {}", id, e);
            redirectAttributes.addFlashAttribute("error", 
                "Error deleting detection result: " + e.getMessage());
        }
        
        return "redirect:/food-detection/history";
    }

    /**
     * Display the home page
     * 
     * @param model the Spring model
     * @return the home view name
     */
    @GetMapping("/")
    public String showHome(Model model) {
        logger.debug("Displaying home page");
        
        try {
            // Get basic statistics for the home page
            FoodDetectionService.DetectionStatistics stats = 
                detectionService.getDetectionStatistics();
            
            model.addAttribute("statistics", stats);
            model.addAttribute("pageTitle", "Food Quality Detector");
            
        } catch (Exception e) {
            logger.error("Error retrieving statistics for home page", e);
            // Don't fail the home page for statistics errors
        }
        
        return "home";
    }
} 