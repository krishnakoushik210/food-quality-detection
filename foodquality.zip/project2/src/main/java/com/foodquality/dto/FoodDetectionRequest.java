package com.foodquality.dto;

import jakarta.validation.constraints.NotNull;
import org.springframework.web.multipart.MultipartFile;

/**
 * Data Transfer Object for food detection requests
 * 
 * This class encapsulates the file upload request and provides
 * validation for the uploaded image file.
 */
public class FoodDetectionRequest {

    h@NotNull(message = "Image file is required")
    private MultipartFile imageFile;

    // Default constructor
    public FoodDetectionRequest() {}

    // Constructor with file
    public FoodDetectionRequest(MultipartFile imageFile) {
        this.imageFile = imageFile;
    }

    // Getters and Setters
    public MultipartFile getImageFile() {
        return imageFile;
    }

    public void setImageFile(MultipartFile imageFile) {
        this.imageFile = imageFile;
    }

    /**
     * Validates if the uploaded file is a valid image
     * 
     * @return true if the file is a valid image, false otherwise
     */
    public boolean isValidImage() {
        if (imageFile == null || imageFile.isEmpty()) {
            return false;
        }

        String contentType = imageFile.getContentType();
        return contentType != null && contentType.startsWith("image/");
    }

    /**
     * Gets the file extension from the original filename
     * 
     * @return the file extension (e.g., ".jpg", ".png")
     */
    public String getFileExtension() {
        if (imageFile == null || imageFile.getOriginalFilename() == null) {
            return "";
        }
        
        String originalFilename = imageFile.getOriginalFilename();
        int lastDotIndex = originalFilename.lastIndexOf('.');
        
        if (lastDotIndex > 0) {
            return originalFilename.substring(lastDotIndex);
        }
        
        return "";
    }
} 