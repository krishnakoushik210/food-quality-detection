package com.foodquality.dto;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for food detection responses
 * 
 * This class encapsulates the result of a food quality detection
 * including classification, confidence score, and metadata.
 */
public class FoodDetectionResponse {

    private Long id;
    private String fileName;
    private String originalFileName;
    private String classification;
    private Double confidenceScore;
    private LocalDateTime uploadTimestamp;
    private Long fileSize;
    private String contentType;
    private String message;
    private boolean success;

    // Default constructor
    public FoodDetectionResponse() {}

    // Constructor for successful detection
    public FoodDetectionResponse(String fileName, String originalFileName, 
                               String classification, Double confidenceScore) {
        this.fileName = fileName;
        this.originalFileName = originalFileName;
        this.classification = classification;
        this.confidenceScore = confidenceScore;
        this.uploadTimestamp = LocalDateTime.now();
        this.success = true;
        this.message = "Food quality detection completed successfully";
    }

    // Constructor for error response
    public FoodDetectionResponse(String message) {
        this.message = message;
        this.success = false;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public Double getConfidenceScore() {
        return confidenceScore;
    }

    public void setConfidenceScore(Double confidenceScore) {
        this.confidenceScore = confidenceScore;
    }

    public LocalDateTime getUploadTimestamp() {
        return uploadTimestamp;
    }

    public void setUploadTimestamp(LocalDateTime uploadTimestamp) {
        this.uploadTimestamp = uploadTimestamp;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    /**
     * Gets the confidence score as a percentage string
     * 
     * @return formatted confidence score (e.g., "85.5%")
     */
    public String getConfidencePercentage() {
        if (confidenceScore == null) {
            return "0%";
        }
        return String.format("%.1f%%", confidenceScore * 100);
    }

    /**
     * Gets a user-friendly classification display
     * 
     * @return formatted classification with confidence
     */
    public String getClassificationDisplay() {
        if (classification == null) {
            return "Unknown";
        }
        return classification + " (" + getConfidencePercentage() + ")";
    }
} 