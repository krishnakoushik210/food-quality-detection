package com.foodquality.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity class representing food detection results
 * 
 * This class maps to the food_detection_results table in the database
 * and stores information about each food quality detection.
 */
@Entity
@Table(name = "food_detection_results")
public class FoodDetectionResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "original_file_name", nullable = false)
    private String originalFileName;

    @Column(name = "classification", nullable = false)
    private String classification;

    @Column(name = "confidence_score", nullable = false)
    private Double confidenceScore;

    @Column(name = "upload_timestamp", nullable = false)
    private LocalDateTime uploadTimestamp;

    @Column(name = "file_size")
    private Long fileSize;

    @Column(name = "content_type")
    private String contentType;

    // Default constructor
    public FoodDetectionResult() {
        this.uploadTimestamp = LocalDateTime.now();
    }

    // Constructor with required fields
    public FoodDetectionResult(String fileName, String originalFileName, 
                             String classification, Double confidenceScore) {
        this();
        this.fileName = fileName;
        this.originalFileName = originalFileName;
        this.classification = classification;
        this.confidenceScore = confidenceScore;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public Double getConfidenceScore() {
        return confidenceScore;
    }

    public void setConfidenceScore(Double confidenceScore) {
        this.confidenceScore = confidenceScore;
    }

    public LocalDateTime getUploadTimestamp() {
        return uploadTimestamp;
    }

    public void setUploadTimestamp(LocalDateTime uploadTimestamp) {
        this.uploadTimestamp = uploadTimestamp;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    @Override
    public String toString() {
        return "FoodDetectionResult{" +
                "id=" + id +
                ", fileName='" + fileName + '\'' +
                ", originalFileName='" + originalFileName + '\'' +
                ", classification='" + classification + '\'' +
                ", confidenceScore=" + confidenceScore +
                ", uploadTimestamp=" + uploadTimestamp +
                ", fileSize=" + fileSize +
                ", contentType='" + contentType + '\'' +
                '}';
    }
} 