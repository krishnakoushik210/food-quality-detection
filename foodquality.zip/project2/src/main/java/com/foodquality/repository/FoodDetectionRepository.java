package com.foodquality.repository;

import com.foodquality.entity.FoodDetectionResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Repository interface for FoodDetectionResult entity
 * 
 * This interface provides data access methods for food detection results
 * including custom queries for analytics and reporting.
 */
@Repository
public interface FoodDetectionRepository extends JpaRepository<FoodDetectionResult, Long> {

    /**
     * Find all results ordered by upload timestamp (newest first)
     * 
     * @return list of food detection results
     */
    List<FoodDetectionResult> findAllByOrderByUploadTimestampDesc();

    /**
     * Find results by classification
     * 
     * @param classification the food quality classification
     * @return list of results with the specified classification
     */
    List<FoodDetectionResult> findByClassificationOrderByUploadTimestampDesc(String classification);

    /**
     * Find results uploaded within a specific time range
     * 
     * @param startTime start of the time range
     * @param endTime end of the time range
     * @return list of results within the specified time range
     */
    List<FoodDetectionResult> findByUploadTimestampBetweenOrderByUploadTimestampDesc(
            LocalDateTime startTime, LocalDateTime endTime);

    /**
     * Find results with confidence score above a threshold
     * 
     * @param minConfidence minimum confidence score
     * @return list of results above the confidence threshold
     */
    List<FoodDetectionResult> findByConfidenceScoreGreaterThanOrderByConfidenceScoreDesc(Double minConfidence);

    /**
     * Count results by classification
     * 
     * @param classification the food quality classification
     * @return count of results with the specified classification
     */
    long countByClassification(String classification);

    /**
     * Get average confidence score by classification
     * 
     * @param classification the food quality classification
     * @return average confidence score for the classification
     */
    @Query("SELECT AVG(f.confidenceScore) FROM FoodDetectionResult f WHERE f.classification = :classification")
    Double getAverageConfidenceByClassification(@Param("classification") String classification);

    /**
     * Get total count of detections
     * 
     * @return total number of food detection results
     */
    @Query("SELECT COUNT(f) FROM FoodDetectionResult f")
    long getTotalDetectionCount();

    /**
     * Get recent results (last N days)
     * 
     * @param days number of days to look back
     * @return list of recent results
     */
    @Query("SELECT f FROM FoodDetectionResult f WHERE f.uploadTimestamp >= :startDate ORDER BY f.uploadTimestamp DESC")
    List<FoodDetectionResult> findRecentResults(@Param("startDate") LocalDateTime startDate);
} 