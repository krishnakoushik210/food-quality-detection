package com.foodquality.service;

import com.foodquality.dto.FoodDetectionResponse;
import com.foodquality.entity.FoodDetectionResult;
import com.foodquality.repository.FoodDetectionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Main business service for food detection operations
 * 
 * This service orchestrates the food quality detection process,
 * manages data persistence, and provides business logic for
 * the application.
 */
@Service
public class FoodDetectionService {

    private static final Logger logger = LoggerFactory.getLogger(FoodDetectionService.class);

    private final FoodQualityDetectionService aiService;
    private final FoodDetectionRepository repository;

    @Autowired
    public FoodDetectionService(FoodQualityDetectionService aiService, 
                              FoodDetectionRepository repository) {
        this.aiService = aiService;
        this.repository = repository;
    }

    /**
     * Process a food image upload and detect quality
     * 
     * @param imageFile the uploaded image file
     * @return FoodDetectionResponse with the detection result
     */
    public FoodDetectionResponse processFoodImage(MultipartFile imageFile) {
        logger.info("Processing food image: {}", imageFile.getOriginalFilename());
        
        try {
            // Validate the uploaded file
            if (imageFile == null || imageFile.isEmpty()) {
                return new FoodDetectionResponse("No image file provided");
            }
            
            if (!isValidImageFile(imageFile)) {
                return new FoodDetectionResponse("Invalid image file. Please upload a valid image.");
            }
            
            // Process the image using AI service
            FoodDetectionResult result = aiService.detectFoodQuality(imageFile);
            
            // Save the result to database
            FoodDetectionResult savedResult = repository.save(result);
            
            // Create response DTO
            FoodDetectionResponse response = new FoodDetectionResponse(
                    savedResult.getFileName(),
                    savedResult.getOriginalFileName(),
                    savedResult.getClassification(),
                    savedResult.getConfidenceScore()
            );
            
            // Set additional metadata
            response.setId(savedResult.getId());
            response.setFileSize(savedResult.getFileSize());
            response.setContentType(savedResult.getContentType());
            response.setUploadTimestamp(savedResult.getUploadTimestamp());
            
            logger.info("Food detection completed successfully for: {}", 
                       savedResult.getOriginalFileName());
            
            return response;
            
        } catch (IOException e) {
            logger.error("Error processing food image: {}", imageFile.getOriginalFilename(), e);
            return new FoodDetectionResponse("Error processing image: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Unexpected error during food detection", e);
            return new FoodDetectionResponse("An unexpected error occurred during processing");
        }
    }

    /**
     * Get all food detection results ordered by timestamp
     * 
     * @return list of all detection results
     */
    public List<FoodDetectionResult> getAllDetectionResults() {
        logger.debug("Retrieving all food detection results");
        return repository.findAllByOrderByUploadTimestampDesc();
    }

    /**
     * Get detection results by classification
     * 
     * @param classification the food quality classification
     * @return list of results with the specified classification
     */
    public List<FoodDetectionResult> getResultsByClassification(String classification) {
        logger.debug("Retrieving results for classification: {}", classification);
        return repository.findByClassificationOrderByUploadTimestampDesc(classification);
    }

    /**
     * Get a specific detection result by ID
     * 
     * @param id the result ID
     * @return Optional containing the result if found
     */
    public Optional<FoodDetectionResult> getDetectionResultById(Long id) {
        logger.debug("Retrieving detection result with ID: {}", id);
        return repository.findById(id);
    }

    /**
     * Get recent detection results (last N days)
     * 
     * @param days number of days to look back
     * @return list of recent results
     */
    public List<FoodDetectionResult> getRecentResults(int days) {
        logger.debug("Retrieving results from last {} days", days);
        LocalDateTime startDate = LocalDateTime.now().minusDays(days);
        return repository.findRecentResults(startDate);
    }

    /**
     * Get statistics about detection results
     * 
     * @return statistics object with counts and averages
     */
    public DetectionStatistics getDetectionStatistics() {
        logger.debug("Retrieving detection statistics");
        
        long totalCount = repository.getTotalDetectionCount();
        long freshCount = repository.countByClassification("Fresh");
        long spoiledCount = repository.countByClassification("Spoiled");
        
        Double freshAvgConfidence = repository.getAverageConfidenceByClassification("Fresh");
        Double spoiledAvgConfidence = repository.getAverageConfidenceByClassification("Spoiled");
        
        return new DetectionStatistics(
                totalCount,
                freshCount,
                spoiledCount,
                freshAvgConfidence != null ? freshAvgConfidence : 0.0,
                spoiledAvgConfidence != null ? spoiledAvgConfidence : 0.0
        );
    }

    /**
     * Delete a detection result by ID
     * 
     * @param id the result ID to delete
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteDetectionResult(Long id) {
        logger.info("Deleting detection result with ID: {}", id);
        
        if (repository.existsById(id)) {
            repository.deleteById(id);
            logger.info("Successfully deleted detection result with ID: {}", id);
            return true;
        } else {
            logger.warn("Attempted to delete non-existent detection result with ID: {}", id);
            return false;
        }
    }

    /**
     * Validate if the uploaded file is a valid image
     * 
     * @param file the uploaded file
     * @return true if valid image, false otherwise
     */
    private boolean isValidImageFile(MultipartFile file) {
        if (file == null) {
            return false;
        }
        
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            return false;
        }
        
        // Check file size (max 10MB)
        if (file.getSize() > 10 * 1024 * 1024) {
            return false;
        }
        
        return true;
    }

    /**
     * Inner class to hold detection statistics
     */
    public static class DetectionStatistics {
        private final long totalCount;
        private final long freshCount;
        private final long spoiledCount;
        private final double freshAvgConfidence;
        private final double spoiledAvgConfidence;

        public DetectionStatistics(long totalCount, long freshCount, long spoiledCount,
                                double freshAvgConfidence, double spoiledAvgConfidence) {
            this.totalCount = totalCount;
            this.freshCount = freshCount;
            this.spoiledCount = spoiledCount;
            this.freshAvgConfidence = freshAvgConfidence;
            this.spoiledAvgConfidence = spoiledAvgConfidence;
        }

        // Getters
        public long getTotalCount() { return totalCount; }
        public long getFreshCount() { return freshCount; }
        public long getSpoiledCount() { return spoiledCount; }
        public double getFreshAvgConfidence() { return freshAvgConfidence; }
        public double getSpoiledAvgConfidence() { return spoiledAvgConfidence; }
        
        public String getFreshAvgConfidencePercentage() {
            return String.format("%.1f%%", freshAvgConfidence * 100);
        }
        
        public String getSpoiledAvgConfidencePercentage() {
            return String.format("%.1f%%", spoiledAvgConfidence * 100);
        }
    }
} 