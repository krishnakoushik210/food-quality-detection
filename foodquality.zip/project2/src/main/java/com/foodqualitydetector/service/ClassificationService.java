package com.foodqualitydetector.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ai.djl.Application;
import ai.djl.ModelException;
import ai.djl.modality.Classifications;
import ai.djl.modality.cv.Image;
import ai.djl.modality.cv.ImageFactory;
import ai.djl.inference.Predictor;
import ai.djl.repository.zoo.Criteria;
import ai.djl.repository.zoo.ModelZoo;
import ai.djl.repository.zoo.ZooModel;
import ai.djl.translate.TranslateException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

@Service
public class ClassificationService {

    private static final Logger logger = LoggerFactory.getLogger(ClassificationService.class);

    private String lastLabel = "Unknown";
    private double lastConfidence = 0.0;

    public String classify(MultipartFile file) {
        try (InputStream is = file.getInputStream()) {
            Image img = ImageFactory.getInstance().fromInputStream(is);

            Criteria<Image, Classifications> criteria =
                    Criteria.builder()
                            .optApplication(Application.CV.IMAGE_CLASSIFICATION)
                            .setTypes(Image.class, Classifications.class)
                            .optFilter("layers", "50")
                            .build();

            try (ZooModel<Image, Classifications> model = ModelZoo.loadModel(criteria);
                 Predictor<Image, Classifications> predictor = model.newPredictor()) {

                Classifications classifications = predictor.predict(img);
                Classifications.Classification best = classifications.best();

                lastLabel = best.getClassName();
                lastConfidence = best.getProbability() * 100;

                logger.info("Predicted label: {}, Confidence: {}", lastLabel, lastConfidence);

                String[] foodKeywords = {
                    "food", "fruit", "vegetable", "meat", "bread", "dish", "egg", "pizza", "cake", "apple", "banana", "orange", "carrot", "potato"
                };
                String[] nonFoodKeywords = {
                    "person", "man", "woman", "face", "human", "boy", "girl"
                };

                String labelLower = lastLabel.toLowerCase();
                boolean isFood = Arrays.stream(foodKeywords)
                                       .anyMatch(k -> labelLower.contains(k));
                boolean isNonFood = Arrays.stream(nonFoodKeywords)
                                          .anyMatch(k -> labelLower.contains(k));

                if (isNonFood || !isFood) {
                    lastLabel = "Not a food image";
                    lastConfidence = 0.0;
                    return "Not a food image";
                }

                if (labelLower.contains("fresh")) {
                    return "Fresh";
                } else {
                    return "Spoiled";
                }
            }
        } catch (IOException | ModelException | TranslateException e) {
            lastLabel = "Error";
            lastConfidence = 0.0;
            logger.error("Error during classification", e);
            return "Error";
        }
    }

    public double getConfidence() {
        return lastConfidence;
    }
}