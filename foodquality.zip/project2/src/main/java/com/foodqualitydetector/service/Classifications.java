package com.foodqualitydetector.service;

public class Classifications {

}
