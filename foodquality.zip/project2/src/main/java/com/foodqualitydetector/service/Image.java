package com.foodqualitydetector.service;

public enum Image {

}
